package Ares;

public class BaseClient {
}
