package Ares.notis;

public enum NotificationType {
   WARNING;

   private static final NotificationType[] ENUM$VALUES = new NotificationType[]{INFO, WARNING, ERROR};
   INFO,
   ERROR;
}
