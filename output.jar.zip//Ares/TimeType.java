package Ares;

public enum TimeType {
   FAST,
   VANILLA;

   private static final TimeType[] ENUM$VALUES = new TimeType[]{DAY, SUNSET, NIGHT, VANILLA, FAST};
   NIGHT,
   SUNSET,
   DAY;
}
