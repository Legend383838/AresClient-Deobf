package Ares;

public class CapeBoolean {
   public static boolean Cape = true;
}
