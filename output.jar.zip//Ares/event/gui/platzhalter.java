package Ares.event.gui;

public class platzhalter {
}
