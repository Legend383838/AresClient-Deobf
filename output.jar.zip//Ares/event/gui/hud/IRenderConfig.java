package Ares.event.gui.hud;

public interface IRenderConfig {
   void save(ScreenPosition var1);

   ScreenPosition load();
}
