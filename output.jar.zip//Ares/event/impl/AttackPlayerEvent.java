package Ares.event.impl;

import Ares.event.Event;

public class AttackPlayerEvent extends Event {
}
