package Ares.event.impl;

import Ares.event.Event;

public class ClientTickEvent extends Event {
}
