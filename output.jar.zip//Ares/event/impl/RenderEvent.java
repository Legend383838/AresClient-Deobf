package Ares.event.impl;

import Ares.event.Event;

public class RenderEvent extends Event {
}
