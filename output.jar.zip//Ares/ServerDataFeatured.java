package Ares;

import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.util.ResourceLocation;

public class ServerDataFeatured extends ServerData {
   public static final ResourceLocation STAR_ICON = new ResourceLocation("Ares/star.png");

   public ServerDataFeatured(String var1, String var2) {
      super(var1, var2, false);
   }
}
